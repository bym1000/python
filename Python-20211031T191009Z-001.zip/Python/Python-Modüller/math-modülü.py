import math

# Modülün İçinde Neler Olduğunu Gösterme Komutu
içinde_ne_var = dir(math)


# Modülün Nasıl Kullanıldığını Gösteren Komut
nasıl_kullanılıyor = help(math)

