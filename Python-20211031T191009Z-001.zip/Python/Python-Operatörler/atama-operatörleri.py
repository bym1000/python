'''
Operatör	Kısa kullanım	Uzun kullanım	 
 	x = 20 y = 5	 
=	x = y	
x = y

x= 5 

+=	x += y	
x = x + y

x= 25
-=	x -= y	
x = x - y

x= 15
*=	x *= y	
x = x * y

x= 100
/=	x /= y	x = x / y	x= 4.0
%=	x %= y 	x = x % y	x= 0
**=	x **= y	x = x ** 2	x= 400
//=	x //= y	x = x // y	x= 4
'''