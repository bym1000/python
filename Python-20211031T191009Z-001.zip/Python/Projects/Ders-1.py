import selenium
from selenium import webdriver
import time
from time import sleep
chrome_driver = r'C:\Users\berat\OneDrive\Masaüstü/chromedriver.exe'
browser = webdriver.Chrome(chrome_driver)
browser.get('https://www.instagram.com/?hl=tr')

time.sleep(500000)





