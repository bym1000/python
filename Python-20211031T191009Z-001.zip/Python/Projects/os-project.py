import os

os.startfile('Temp')


