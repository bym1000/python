name = 'Berat Karakuş'
for i in name:
  if i =='a':
    break
# a Harfine Geldiği Zaman Döngüyü Durdurdu

for i in name:
  if i == 'B':
    continue
# B harfini gördüğü zaman es geçerek diğer harflere geçti


x = 0
while x < 5:
  x+=1
  if x == 2:
    continue
  print(x)






# 1 den 100 e kadar olan sayıların hepsini topla !,


b =  1
result = 0

while x <= 100:
  result += x
  x += 1

print(f'toplam : {result}')




# Deneme
a = 1

while a <= 100:
  a += 1
  if a == 31:
    print('SJ')
    continue
  print(a)









  