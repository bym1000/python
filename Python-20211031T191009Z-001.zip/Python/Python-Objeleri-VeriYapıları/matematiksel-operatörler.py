# Pythonda kullanabilecek olduğumuz temel matematiksel operatörler şu şekildedir.

# +	Toplama	
# 10 + 15

# 25
# -	Çıkarma	
# 15 - 10
# 5

# *	Çarpma	
# 2 * 5
# 10

# /	Bölme	8 / 2	4.0
# %	Mod Alma	15 % 2	1
# **	Üs alma	2 ** 3	8
# //	Kalansız Bölme	15 // 2	7
# Toplama Operatörü (+)
# 100 + 50
# Toplama operatörüne göre 100 ve 50 sayısı toplanır.

# Çıkarma Operatörü (-)
# (100 + 50) - 50
# Parantez içindeki 100 + 50 işleminden sonra 50 değerini 150 'den çıkartırız ve sonuç 100 olur.

# Çarpma Operatörü (*)
# (2 + 6) * (6 - 2);
# Parantez içlerindeki (2+6)' nin değeri 8 ile (4-6)' nin değeri -2 çarpılır ve sonuç -16 olarak hesaplanır.

# Bölme Operatörü (/)
# (5 * 2) / 2;
# Parantez içindeki (5*2)' nin değeri 10 sayısı 2' e bölünür ve sonuç 5.0 olarak hesaplanır.

# Mod Alma Operatörü (%)
# 1001 % 2;
# 1001 sayısının 2' e kalansız bölümünden elde edilen sayı 1' dir. 

# Üs Alma Operatörü (**)
# 5 ** 2;    
# 5' in 2 sayısı ile üssünü almış oluyoruz. Dolayısıyla 5' in yan yana 2 kere çarpımı 25 sonucunu verir.

# Kalansız Bölme (//)
# 17 // 7
# 17' nin 7'e kalansız bölümünden elde edilen sayı 2' dir. Burada kalan sayıyı atmış oluyoruz.